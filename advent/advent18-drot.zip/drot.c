#include <SDL.h>
#include <SDL_gfxPrimitives.h>
#include <math.h>
#include <ctype.h>

Uint32 const szinek[] = { 0x000000FF, 0x008000FF, 0xFF0000FF, 0x0000FFFF, 0xFF00FFFF };


typedef struct Pont Pont;
struct Pont {
    double x, y, z;     /* eredeti 3d koordináta */
    int hanyadik;       /* fájlbeli sorszám */

    double xf, yf, zf;  /* forgatott 3d koordináta */
    int xk, yk;         /* képernyőn koordináta */
    Pont *kov;
};

typedef struct Vonal Vonal;
struct Vonal {
    int pi1, pi2;   /* pontok indexe, amit osszekot */
    Pont *p1, *p2;  /* pointer rájuk, hogy ne kelljen mindig megkeresni */
    int szin;       /* színkód a fenti tömbből */
    Vonal *kov;
};

typedef struct Szoveg Szoveg;
struct Szoveg {
    char felirat[100];  /* felirat szövege */
    int x, y, szin;     /* pozíció és szín */
    Szoveg *kov;
};

typedef struct Rajz Rajz;
struct Rajz {
    Pont *pontok;
    Vonal *vonalak;
    Szoveg *szovegek;
    int latszik[5];     /* melyik színű vonalak látszanak épp */
};


/* Beolvassa a fajlnev nevű fájlt a rajz inicializálatlan struktúrába.
 * Igazzal tér vissza, ha minden oké. */
int beolvas(char const *fajlnev, Rajz *rajz) {
    /* inicializálás */
    {
        int i;
        rajz->latszik[0] = 0;
        for (i=1; i<5; ++i)
            rajz->latszik[i] = 1;
        rajz->pontok = NULL;        /* üres listák */
        rajz->vonalak = NULL;
        rajz->szovegek = NULL;
    }
    
    /* fájlból olvasás */
    {
        char sor[100];
        FILE *fp;

        fp = fopen(fajlnev, "rt");
        if (fp == NULL) {
            return 0;
        }
        while (fgets(sor, sizeof(sor), fp)) {
            char tipus;
            
            /* üres sort és kommentet szkippeljük */
            if (sscanf(sor, " %c", &tipus)!=1 || tipus==';')
                continue;

            /* a sor első betűje mutatja a típust */
            switch (tolower(tipus)) {
                case 's':   /* szöveg */
                    {
                        Szoveg *uj = (Szoveg *) malloc(sizeof(Szoveg));
                        sscanf(sor, " %*c %d %d %d %[^\r\n]", &uj->x, &uj->y, &uj->szin, uj->felirat);
                        uj->kov = rajz->szovegek;
                        rajz->szovegek = uj;
                    }
                    break;
                case 'p':   /* pont */
                    {
                        Pont *uj = (Pont *) malloc(sizeof(Pont));
                        sscanf(sor, " %*c %d %lf %lf %lf", &uj->hanyadik, &uj->x, &uj->y, &uj->z);
                        uj->kov = rajz->pontok;
                        rajz->pontok = uj;
                    }
                    break;
                case 'l':   /* vonal két pont között */
                    {
                        Vonal *uj = (Vonal *) malloc(sizeof(Vonal));
                        sscanf(sor, " %*c %d %d %d", &uj->szin, &uj->pi1, &uj->pi2);
                        uj->kov = rajz->vonalak;
                        rajz->vonalak = uj;
                    }
                    break;
            }
        }
        fclose(fp);
    }

    /* megkeressük a vonalakhoz tartozó pontokat */
    {
        Vonal *von;
        
        for (von=rajz->vonalak; von!=NULL; von=von->kov) {
            Pont *iter;
            
            /* megkeressük a két pontot */
            for (iter=rajz->pontok; iter!=NULL && iter->hanyadik!=von->pi1; iter=iter->kov)
                ;   /* üres */
            if (iter == NULL)   /* hiányzik? */
                return 0;
            von->p1 = iter;

            for (iter=rajz->pontok; iter!=NULL && iter->hanyadik!=von->pi2; iter=iter->kov)
                ;   /* üres */
            if (iter == NULL)   /* hiányzik? */
                return 0;
            von->p2 = iter;
        }
    }
    
    return 1;
}


/* listák felszabadítása - láthatóan eléggé jól jönne egy generikus lista */
void rajz_felszabadit(Rajz *rajz) {
    while (rajz->vonalak) {
        Vonal *temp = rajz->vonalak->kov;
        free(rajz->vonalak);
        rajz->vonalak = temp;
    }
    while (rajz->pontok) {
        Pont *temp = rajz->pontok->kov;
        free(rajz->pontok);
        rajz->pontok = temp;
    }
    while (rajz->szovegek) {
        Szoveg *temp = rajz->szovegek->kov;
        free(rajz->szovegek);
        rajz->szovegek = temp;
    }
}

void forgat_es_vetit(SDL_Surface *screen, Rajz *rajz, double szog, double d) {
    Pont *pont;
    
    /* beforgatás */
    for (pont=rajz->pontok; pont!=NULL; pont=pont->kov) {
        Pont p = *pont; /* csak a kényelem miatt */
        
        /* forgatás: előbb x, aztán y, végül z tengely körül, aztán eltárolás */
        Pont fx = {p.x, p.y*cos(szog)-p.z*sin(szog), p.y*sin(szog)+p.z*cos(szog)};
        Pont fy = {fx.x*cos(szog)-fx.z*sin(szog), fx.y, fx.x*sin(szog)+fx.z*cos(szog)};
        Pont fz = {fy.x*cos(szog)-fy.y*sin(szog), fy.x*sin(szog)+fy.y*cos(szog), fy.z};
        pont->xf = fz.x;
        pont->yf = fz.y;
        pont->zf = fz.z;
        /* perspektíva */
        pont->xk = +d * pont->xf/(pont->zf + d) + screen->w/2;
        pont->yk = -d * pont->yf/(pont->zf + d) + screen->h/2;
    }
}

void kirajzol(SDL_Surface *screen, Rajz const *rajz, double szog, double d) {
    Szoveg *szov;
    Vonal *von;
    Pont *pont;
    char felirat[]="0: szamok lathatosaga     1, 2, 3, 4: vonalak lathatosaga     ESC: kilep";

    /* rajzolás */
    boxColor(screen, 0, 0, screen->w - 1, screen->h - 1, 0xFFFFFFFF);
    for (szov=rajz->szovegek; szov!=NULL; szov=szov->kov) {
        stringColor(screen, szov->x, szov->y, szov->felirat, szinek[szov->szin]);
    }
    for (von=rajz->vonalak; von!=NULL; von=von->kov) {
        if (rajz->latszik[von->szin]) {
            aalineColor(screen, von->p1->xk, von->p1->yk, von->p2->xk, von->p2->yk, szinek[von->szin]);
            aalineColor(screen, von->p1->xk, von->p1->yk+1, von->p2->xk, von->p2->yk+1, szinek[von->szin]); /* vastagít */
        }
    }
    /* a 0-s láthatóság a pontok sorszámait mutatja */
    if (rajz->latszik[0])
        for (pont=rajz->pontok; pont!=NULL; pont=pont->kov) {
            char s[10];
            int hossz;
            hossz = sprintf(s, "%d", pont->hanyadik);
            stringColor(screen, pont->xk - hossz*4, pont->yk - 4, s, szinek[0]);
        }
    
    stringColor(screen, (screen->w - strlen(felirat)*8)/2, screen->h-10, felirat, szinek[0]);
    SDL_Flip(screen);
}


Uint32 idozit(Uint32 ms, void* param) {
    SDL_Event ev;
    ev.type = SDL_USEREVENT;
    SDL_PushEvent(&ev);
    return ms;   /* ujabb varakozas */
}


int main(int argc, char *argv[]) {
    SDL_Surface *screen;
    Rajz rajz;
    double szog;
    SDL_TimerID id;
    int kilep;
    SDL_Event event;
    double d;
    
    if (!beolvas(argv[1] ? argv[1] : "foci.3d", &rajz)) {
        fprintf(stderr, "Nem lehet megnyitni a fajlt\n");
        return 1;
    }

    /* SDL inicializálása és ablak megnyitása */
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER);
    screen=SDL_SetVideoMode(640, 480, 0, SDL_ANYFORMAT);
    if (!screen) {
        fprintf(stderr, "Nem sikerult megnyitni az ablakot!\n");
        return 2;
    }
    SDL_WM_SetCaption("Drotvaz 3D", "Drotvaz 3D");
    
    id = SDL_AddTimer(40, idozit, NULL);
    kilep = 0;
    /* eseményhurok */
    szog = 0.3;
    d = 800;
    while (!kilep) {
        SDL_WaitEvent(&event);
        
        switch (event.type) {
            case SDL_KEYDOWN:
                switch (event.key.keysym.sym) {
                    case SDLK_0: rajz.latszik[0] = !rajz.latszik[0]; break;
                    case SDLK_1: rajz.latszik[1] = !rajz.latszik[1]; break;
                    case SDLK_2: rajz.latszik[2] = !rajz.latszik[2]; break;
                    case SDLK_3: rajz.latszik[3] = !rajz.latszik[3]; break;
                    case SDLK_4: rajz.latszik[4] = !rajz.latszik[4]; break;
                    case SDLK_UP: if (d>=200) d -= 25; break;
                    case SDLK_DOWN: d += 25; break;
                    case SDLK_ESCAPE: kilep = 1; break;
                    default: break;
                }
                break;
            case SDL_USEREVENT:
                forgat_es_vetit(screen, &rajz, szog, d);
                kirajzol(screen, &rajz, szog, d);
                szog+=0.01;
                break;
            case SDL_QUIT:
                kilep = 1;
                break;
        }
    }
    SDL_RemoveTimer(id);
    
    rajz_felszabadit(&rajz);
    
    SDL_Quit();
    
    return 0;
}
