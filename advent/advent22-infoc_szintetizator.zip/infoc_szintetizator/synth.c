#include <SDL.h>
#include <SDL_keysym.h>
#include <math.h>

#include "synth.h"

#define PI 3.14159265

/* nehany globalis valtozo a hangok adataihoz */
static SDL_AudioSpec audiospec;
static double t = 0;                   /* az eltelt ido */


/* ez hivodik meg, amikor az SDL ujabb adag hangot ker tolunk */
void hang_callback(void *userdata, Uint8 * stream8, int len) {
    Szinti *sz = (Szinti *) userdata;
    Sint16 *stream = (Sint16 *) stream8;        /* a puffer, amit kaptunk: signed integer, 16 bit */
    double dt = 1.0 / audiospec.freq;   /* ennyi masodperc hangmintankent */
    int mintak;
    int x, i;

    mintak = len / sizeof(stream[0]);         /* mert bajtban szamol, nekunk meg mintak szama kell */

    /* vegigmegyunk ezen az idoszeleten */
    for (x = 0; x < mintak; x++) {
        double s = 0;           /* az aktualis minta */

        /* es osszegzunk (osszemixelunk) minden hangot */
        for (i = 0; sz->hangok[i].sym != SDLK_UNKNOWN; ++i) {
            Hang *h = &sz->hangok[i];
            HangSzin *hsz = sz->hangszin;
            double s_ez;
            int felh;

            /* felharmonikusok osszegzese */
            s_ez = 0;
            if (h->all != csend) {
                for (felh = 0; hsz->felharm[felh].frekszorzo != 0; ++felh)
                    if (hsz->felharm[felh].arany != 0)
                        s_ez +=
                            hsz->felharm[felh].arany * sin(hsz->felharm[felh].frekszorzo * h->frek *
                                                           2 * PI * t +
                                                           2*hsz->fazis_mod_ampl *
                                                           sin(hsz->fazis_mod_frek * 25 * 2 * PI * t));
            }

            /* itt kezeli a burkologorbet */
            switch (h->all) {
            case csend:
                if (h->szol)
                    h->all = felfutas;
                break;
            case felfutas:
                h->hangero += 1.0 / (hsz->felfutas_ido + 0.01) * dt;
                if (h->hangero > 1)
                    h->all = lecsenges;
                if (!h->szol)
                    h->all = elengedes;
                break;
            case lecsenges:
                h->hangero -= 1.0 / (hsz->lecsenges_ido + 0.01) * dt;
                if (h->hangero < hsz->tartas_hangero)
                    h->all = tartas;
                if (!h->szol)
                    h->all = elengedes;
                break;
            case tartas:
                if (!h->szol)
                    h->all = elengedes;
                break;
            case elengedes:
                h->hangero -= 1.0 / (hsz->elengedes_ido + 0.01) * dt;
                if (h->hangero < 0) {
                    h->hangero = 0;
                    h->all = csend;
                }
                break;
            }

            s += s_ez * h->hangero * sz->hangero;
        }
        /* itt tortenik az amplitudo modulacioja */
        s *= (1 + sz->hangszin->amplmod_ampl * sin(sz->hangszin->amplmod_frek * 25 * 2 * PI * t));

        /* itt bekerul a pufferbe az osszemixelt minta */
        stream[x] = s;

        t += dt;                /* eltelt ennyi ido */
    }
}


/* SDL hanglejatszas inditasa */
void hang_init(Szinti *szinti) {
    audiospec.freq = 44100;                /* 44100Hz - CD minoseg, 48000 - dvd minoseg */
    audiospec.format = AUDIO_S16SYS;       /* 16-bit elojeles; a rendszer bajtsorrendjevel */
    audiospec.channels = 1;                /* mono */
    audiospec.samples = audiospec.freq/50; /* puffer merete - 1/50 sec */
    audiospec.callback = hang_callback;    /* sdl hivja, ha ujabb adag hang kell neki */
    audiospec.userdata = (void *) szinti;  /* egy pointert atad mindig a callbacknek */
    if (SDL_OpenAudio(&audiospec, NULL) < 0) {
        fprintf(stderr, "Hiba a hanggal: %s\n", SDL_GetError());
        exit(1);
    }
}


/* hang inditasa */
void hang_start(void) {
    SDL_PauseAudio(0);
}


/* hang inditasa */
void hang_stop(void) {
    SDL_PauseAudio(1);
}
