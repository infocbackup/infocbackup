#ifndef WIDGET_H
#define WIDGET_H

#include <SDL.h>

extern SDL_Surface *screen;


/* egy widget, az altalanos es a specialis adatokkal */
typedef struct Widget Widget;
struct Widget {
    int x, y, szeles, magas;    /* pozicio es meret */

    /* kirajzolashoz hasznalt fv */
    void (*rajzolo_fv) (Widget *widget);
    void (*kattintas_fv) (Widget *widget, int x, int y);
    /* kattintaskor ez hivodik, ha nem NULL */
    void (*felhasznaloi_cb) (Widget *widget, int x, int y, void *param);
    void *felhasznaloi_cb_param;        /* ezt a parametert megkapja a param valtozoban */

    enum WidgetTipus {          /* ilyen tipusu lehet */
        altalanos, gomb, csuszka, felirat
    } tipus;
    union {
        struct GombAdat {
            char felirat[20];   /* a gomb szovege */
        } gomb;
        struct CsuszkaAdat {
            double jelenlegi;   /* erteke; 0.0-1.0 */
        } csuszka;
        struct FeliratAdat {
            char szoveg[20];
        } felirat;
    } adat;
};


void widget_init(char *ablaknev, int w, int h);
void kilep_gomb_cb(Widget *widget, int x, int y, void *param);
void widget_alap_rajzol(Widget *widget);

Widget *uj_widget(int x, int y, int szeles, int magas);
Widget *uj_gomb(int x, int y, int szeles, int magas, char const *felirat);
Widget *uj_felirat(int x, int y, char const *szoveg);
Widget *uj_csuszka(int x, int y, int szeles, int magas, double kezdeti);

void esemenyvezerelt_main(Widget *widgetek[]);

void billentyuzet_cb_megad(void (*cb) (SDL_KeyboardEvent *, void *), void *param);

#endif
