#include <stdio.h>
#include <string.h>
#include "ertelmezo.h"

int main() {
    char szoveg[255] = "";
    szimbolum *ast = NULL;

    printf("Adj meg tetszőleges, zárójeles, négy alapműveletes kifejezéseket!\n");
    printf("Kilépés fájl vége jelre.\n\n");

    while (fgets(szoveg, 254, stdin) != NULL) {
        if (kiertekel(szoveg, &ast)) {
            printf("A kifejezés értéke: %g.\n", ast_kiertekel(ast));
            ast_torol(ast);
        }
        else {
            printf("Nem sikerült értelmezni a kifejezést.\n");
        }
    };

    return 0;
}

