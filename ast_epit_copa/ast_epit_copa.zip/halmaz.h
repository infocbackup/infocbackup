#ifndef HALMAZ
#define HALMAZ

typedef struct valtozo {
	char nev[51];
	double ertek;
	struct valtozo *kovetkezo;
} valtozo;

/**
	Ez használható lekérdezésre és behelyezésre is. Ha még nincs
	benne a változó a halmazban, akkor berakja és nullára inicializálja.
 */
double *lekerdez(valtozo **valtozok, char const *nev);

#endif
