#include "ertelmezo.h"

typedef struct kifejezesek {
	char szoveg[255];
	szimbolum *ast; 
	struct kifejezesek *kovetkezo;
} kifejezesek;

void kifejezesek_vegere_berak(kifejezesek **a_kifejezesek, char const *szoveg, szimbolum *ast);

/*
 * Visszaadja az egyenlet_szam. egyenletet és az egyenlet_szoveg változóba bemásolja a szövegét.
 */
szimbolum *kifejezesek_leker(kifejezesek *a_kifejezesek, unsigned egyenlet_szam, char *egyenlet_szoveg);

void kifejezesek_torol(kifejezesek *a_kifejezesek);
