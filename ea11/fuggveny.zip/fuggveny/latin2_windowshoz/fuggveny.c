#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fuggveny.h"

/** A koordin�tarendszer rajzol�s�hoz haszn�lt sz�n. */
static const char alapszin[] = "black";
/** A ny�l �s az egys�gjel m�rete a koordin�tarendszeren */
static const int nyilmeret = 5;

/** K�perny� koordin�t�b�l matematikai koordin�t�t sz�mol.
 * @param r A rajz, amin dolgozik. Ebb�l veszi ki a nagy�t�st �s az orig� adatait.
 * @param kx A k�perny� x koordin�ta, amit �t kell sz�molni.
 * @param ky A k�perny� y koordin�ta, amit �t kell sz�molni.
 * @param mx Pointer a matematikai x koordin�t�ra, ahova az eredm�ny ker�l, vagy NULL, ha nincs r� sz�ks�g.
 * @param my Pointer a matematikai y koordin�t�ra, ahova az eredm�ny ker�l, vagy NULL, ha nincs r� sz�ks�g.
 */
static void kep2mat(Rajz const *r, double kx, double ky, double *mx, double *my) {
    if (mx!=NULL)
        *mx = (kx - r->ox) / r->nx;
    if (my!=NULL)
        *my = -(ky - r->oy) / r->ny;
}


/** Matematikai koordin�t�b�l k�pkoordin�t�t sz�m�t.
 * Ha a kx, ky kimeneti param�terek valamelyik�ben NULL pointert kap, akkor
 * azt a koordin�t�t nem t�rolja el.
 * @param r A rajz, amin dolgozik. Ebb�l veszi ki a nagy�t�st �s az orig� adatait.
 * @param mx A matematikai x koordin�ta, amit �t kell sz�molni.
 * @param my A matematikai y koordin�ta, amit �t kell sz�molni.
 * @param kx Pointer a k�perny� x koordin�t�ra, ahova az eredm�ny ker�l, vagy NULL.
 * @param ky Pointer a k�perny� y koordin�t�ra, ahova az eredm�ny ker�l, vagy NULL.
 */
static void mat2kep(Rajz const *r, double mx, double my, double *kx, double *ky) {
    if (kx!=NULL)
        *kx = r->ox + mx*r->nx;
    if (ky!=NULL)
        *ky = r->oy - my*r->ny;
}


/**
 * Szakaszt rajzol egy rajzra.
 * @param x1 A szakasz egyik v�gpontj�nak x koordin�t�ja.
 * @param y1 A szakasz egyik v�gpontj�nak y koordin�t�ja.
 * @param x1 A szakasz m�sik v�gpontj�nak x koordin�t�ja.
 * @param y1 A szakasz m�sik v�gpontj�nak y koordin�t�ja.
 * @param szin A szakasz sz�ne, egy SDL-kompatibilis megad�ssal (pl. "red" vagy "#009900").
 * @return 1, ha minden rendben; 0, ha nem siker�lt.
 */
static int szakasz_rajzol(Rajz *r, double x1, double y1, double x2, double y2, char const *szin) {
    Szakasz *uj;

    /* �j ter�let foglal�sa */
    uj = (Szakasz *) malloc(sizeof(Szakasz));
    if (uj == NULL)
        return 0;
    /* adatok bem�sol�sa */
    uj->x1 = x1;
    uj->y1 = y1;
    uj->x2 = x2;
    uj->y2 = y2;
    strcpy(uj->szin, szin);
    /* lista v�g�hez f�z�s */
    uj->kov = NULL;
    if (r->szakaszok == NULL) {
        r->szakaszok = uj;
    } else {
        /* megkeresi a lista v�g�t, �s hozz�f�zi. */
        /* TODO: sz�p lenne a strukt�r�ban egy lista v�ge pointert is
         * tartani, hogy ezt a keres�st ne kelljen mindig megtenni. */
        Szakasz *iter;
        for (iter = r->szakaszok; iter->kov != NULL; iter = iter->kov)
            ;
        iter->kov = uj;
    }

    /* minden ok */
    return 1;
}


/* �j rajzot kezd. Ennek egy inicializ�latlan strukt�r�ra mutat�
 * pointert kell adni. Maga a strukt�ra m�r le kell legyen foglalva! */
void rajz_inicializal(Rajz *r, int kx, int ky, double ox, double oy, double nx, double ny) {
    /* Megjegyzi a nagy�t�st �s az eltol�st */
    r->kx = kx;
    r->ky = ky;
    r->ox = ox;
    r->oy = oy;
    r->nx = nx;
    r->ny = ny;
    /* �res lista; NULL pointer, hogy ne az inicializ�latlan strukt�r�ra
     * h�vjuk r� az �res koordin�tarendszert rajzol� f�ggv�nyt. */
    r->szakaszok = NULL;
    rajz_ures(r);
}


/* Felszabad�tja a rajz �ltal foglalt ter�letet.
 * Maga a strukt�ra nem felt�tlen�l dinamikusan foglalt, ez�rt azt ez
 * a f�ggv�ny nem szabad�tja fel! */
void rajz_felszabadit(Rajz *r) {
    while (r->szakaszok != NULL) {
        Szakasz *kov = r->szakaszok->kov;
        free(r->szakaszok);
        r->szakaszok = kov;
    }
}

/* M�r inicializ�lt rajzot t�r�l. */
void rajz_ures(Rajz *r) {
    double ex, ey;

    /* Kezdetben nincs rajta vonal: a lista felszabad�t�sa. */
    while (r->szakaszok != NULL) {
        Szakasz *kov = r->szakaszok->kov;
        free(r->szakaszok);
        r->szakaszok = kov;
    }
    /* Koordin�tarendszer, x tengely */
    szakasz_rajzol(r, 0, r->oy, r->kx, r->oy, alapszin);
    szakasz_rajzol(r, r->kx, r->oy, r->kx-nyilmeret*2, r->oy-nyilmeret, alapszin);
    szakasz_rajzol(r, r->kx, r->oy, r->kx-nyilmeret*2, r->oy+nyilmeret, alapszin);
    /* Koordin�tarendszer, y tengely */
    szakasz_rajzol(r, r->ox, 0, r->ox, r->ky, alapszin);
    szakasz_rajzol(r, r->ox, 0, r->ox-nyilmeret, nyilmeret*2, alapszin);
    szakasz_rajzol(r, r->ox, 0, r->ox+nyilmeret, nyilmeret*2, alapszin);
    /* egys�gek */
    mat2kep(r, 1, 1, &ex, &ey);
    szakasz_rajzol(r, ex, r->oy-nyilmeret, ex, r->oy+nyilmeret, alapszin);
    szakasz_rajzol(r, r->ox-nyilmeret, ey, r->ox+nyilmeret, ey, alapszin);
}


/* Kirajzol egy f�ggv�nyt. */
int fuggveny_rajzol(Rajz *r, double (*fv)(double), char const *szin) {
    double const lepes = 1.0;
    double xk, yk, xelozo, yelozo;  /* k�p koordin�t�k */

    /* Haladjunk a k�p koordin�t�i szerint, �gy pont olyan
     * r�szletess�get kapunk, mint amekkora a k�p. */
    for (xk=0; xk<=r->kx; xk+=lepes) {
        double xmat, ymat;

        /* Melyik matematikai x koordin�ta felel meg ennek? */
        kep2mat(r, xk, 0, &xmat, NULL);
        /* Azt kell a f�ggv�nybe behelyettes�teni */
        ymat=fv(xmat);
        /* Visszasz�molni k�pkoordin�t�kra megint */
        mat2kep(r, xmat, ymat, NULL, &yk);
        /* Ut�na rajz (kiv�tel a legels� helyen, mert azel�tt
         * m�g nincs el�z� pont). */
        if (xk!=0)
            if (!szakasz_rajzol(r, xk, yk, xelozo, yelozo, szin))
                /* ha baj van a rajzol�ssal, meg�llunk */
                return 0;

        /* a k�vetkez� iter�ci� sz�m�ra */
        xelozo = xk;
        yelozo = yk;
    }

    /* siker�lt teljesen kirajzolni, visszat�r�nk igaz �rt�kkel */
    return 1;
}


/* Nyitott f�jlba rakja az SVG elemeket. */
void rajz_kiir(Rajz const *r, FILE *fp) {
    Szakasz *iter;

    fprintf(fp, "<svg width=\"%d\" height=\"%d\" xmlns=\"http://www.w3.org/2000/svg\">\n",
        r->kx, r->ky);
    for (iter = r->szakaszok; iter != NULL; iter = iter->kov)
        fprintf(fp, "  <line x1=\"%g\" y1=\"%g\" x2=\"%g\" y2=\"%g\" stroke=\"%s\" />\n",
            iter->x1, iter->y1, iter->x2, iter->y2, iter->szin);
    fprintf(fp, "</svg>\n");
}


/* Adott nev� f�jlba �rja a rajzot. */
void rajz_fajlba(Rajz const *r, char const *nev) {
    FILE *fp;

    fp = fopen(nev, "wt");
    if (fp==NULL)   /* Nem siker�lt megnyitni? */
        return;
    rajz_kiir(r, fp);
    fclose(fp);
}
