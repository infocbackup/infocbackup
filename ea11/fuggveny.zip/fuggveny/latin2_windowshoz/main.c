#include <stdio.h>
#include <math.h>
#include <string.h>
#include "fuggveny.h"

/**
 * @mainpage
 * Ez az el�ad�son bemutatott f�ggv�nyrajzol� program
 * dokument�ci�ja.
 */

/* Ez a strukt�ra egy parabola egy�tthat�it t�rolja. */
typedef struct parabola_t {
    double a, /**< A m�sodfok� tag egy�tthat�ja. */
           b, /**< Az els�fok� tag egy�tthat�ja. */
           c; /**< A nulladfok� (konstans) tag. */
} parabola_t;
/** Glob�lis v�ltoz� a parabola() f�ggv�ny sz�m�ra.
 * Ezekre az�rt van sz�ks�g, mert a parabola is egy y=f(x)
 * alak� f�ggv�ny kell legyen, vagyis csak egy param�tere
 * lehet (az x). Az egy�tthat�kat m�s m�don kell megadni neki. */
static parabola_t parabola_adat;

/** Visszaadja x*x-x-1.5 �rt�k�t.
 * @param x A sz�m, amit a f�ggv�nybe be kell helyettes�teni.
 * @return A f�ggv�ny �rt�ke. */
static double parabola(double x) {
    return parabola_adat.a*x*x + parabola_adat.b*x + parabola_adat.c;
}


/** Ki�rja a felhaszn�l�i men�t (f�men�), �s megk�rdezi a felhaszn�l� v�laszt�s�t.
 * @return A v�lasztott men� sorsz�ma, vagy 0 a kil�p�shez (�s hiba eset�n). */
static int menu(void) {
    int valaszt, sik;

    printf("Men� (0: kil�p�s)\n");
    printf("  1. sin(x) rajzol�sa\n");
    printf("  2. axx+bx+c parabola rajzol�sa\n");
    printf("  3. T�rl�s\n");
    printf("  4. F�jlba ment�s\n");
    printf("? ");
    /* A men� sz�m�nak beolvas�sa. Az ut�na nyomott entert a getchar() lenyeli. */
    sik = scanf("%d", &valaszt)==1;
    getchar();
    /* Beolvas�si hiba? 0-t adunk vissza (kil�p�snek megfelel�) */
    if (!sik)
        return 0;
    /* Tartom�ny ok�? Ha nem, 0-t ad vissza */
    if (valaszt>4 || valaszt<0)
        return 0;
    /* A v�lasztott men�pont */
    return valaszt;
}


/**
 * F�program. */
int main(int argc, char *argv[]) {
    enum { FAJLNEV_TOMB = 100 };
    char fajlnev[FAJLNEV_TOMB];
    Rajz r1;
    int v;

    rajz_inicializal(&r1, 320, 120, 160, 60, 25, 25);

    do {
        v = menu();
        switch (v) {
            case 1:
                fuggveny_rajzol(&r1, sin, "blue");
                break;
            case 2:
                printf("A parabola egy�tthat�i:\n");
                scanf("%lf %lf %lf", &parabola_adat.a,
                    &parabola_adat.b, &parabola_adat.c);
                fuggveny_rajzol(&r1, parabola, "red");
                break;
            case 3:
                rajz_ures(&r1);
                break;
            case 4:
                printf("Mi legyen a f�jl neve?\n");
                fgets(fajlnev, FAJLNEV_TOMB, stdin);
                /* fgets beleteszi az entert is, kitoroljuk */
                *strchr(fajlnev, '\n') = 0;
                rajz_fajlba(&r1, fajlnev);
                break;
        }
    } while (v != 0);

    rajz_felszabadit(&r1);

    return 0;
}

