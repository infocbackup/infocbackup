#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fuggveny.h"

/** A koordinátarendszer rajzolásához használt szín. */
static const char alapszin[] = "black";
/** A nyíl és az egységjel mérete a koordinátarendszeren */
static const int nyilmeret = 5;

/** Képernyő koordinátából matematikai koordinátát számol.
 * @param r A rajz, amin dolgozik. Ebből veszi ki a nagyítást és az origó adatait.
 * @param kx A képernyő x koordináta, amit át kell számolni.
 * @param ky A képernyő y koordináta, amit át kell számolni.
 * @param mx Pointer a matematikai x koordinátára, ahova az eredmény kerül, vagy NULL, ha nincs rá szükség.
 * @param my Pointer a matematikai y koordinátára, ahova az eredmény kerül, vagy NULL, ha nincs rá szükség.
 */
static void kep2mat(Rajz const *r, double kx, double ky, double *mx, double *my) {
    if (mx!=NULL)
        *mx = (kx - r->ox) / r->nx;
    if (my!=NULL)
        *my = -(ky - r->oy) / r->ny;
}


/** Matematikai koordinátából képkoordinátát számít.
 * Ha a kx, ky kimeneti paraméterek valamelyikében NULL pointert kap, akkor
 * azt a koordinátát nem tárolja el.
 * @param r A rajz, amin dolgozik. Ebből veszi ki a nagyítást és az origó adatait.
 * @param mx A matematikai x koordináta, amit át kell számolni.
 * @param my A matematikai y koordináta, amit át kell számolni.
 * @param kx Pointer a képernyő x koordinátára, ahova az eredmény kerül, vagy NULL.
 * @param ky Pointer a képernyő y koordinátára, ahova az eredmény kerül, vagy NULL.
 */
static void mat2kep(Rajz const *r, double mx, double my, double *kx, double *ky) {
    if (kx!=NULL)
        *kx = r->ox + mx*r->nx;
    if (ky!=NULL)
        *ky = r->oy - my*r->ny;
}


/**
 * Szakaszt rajzol egy rajzra.
 * @param x1 A szakasz egyik végpontjának x koordinátája.
 * @param y1 A szakasz egyik végpontjának y koordinátája.
 * @param x1 A szakasz másik végpontjának x koordinátája.
 * @param y1 A szakasz másik végpontjának y koordinátája.
 * @param szin A szakasz színe, egy SDL-kompatibilis megadással (pl. "red" vagy "#009900").
 * @return 1, ha minden rendben; 0, ha nem sikerült.
 */
static int szakasz_rajzol(Rajz *r, double x1, double y1, double x2, double y2, char const *szin) {
    Szakasz *uj;

    /* új terület foglalása */
    uj = (Szakasz *) malloc(sizeof(Szakasz));
    if (uj == NULL)
        return 0;
    /* adatok bemásolása */
    uj->x1 = x1;
    uj->y1 = y1;
    uj->x2 = x2;
    uj->y2 = y2;
    strcpy(uj->szin, szin);
    /* lista végéhez fűzés */
    uj->kov = NULL;
    if (r->szakaszok == NULL) {
        r->szakaszok = uj;
    } else {
        /* megkeresi a lista végét, és hozzáfűzi. */
        /* TODO: szép lenne a struktúrában egy lista vége pointert is
         * tartani, hogy ezt a keresést ne kelljen mindig megtenni. */
        Szakasz *iter;
        for (iter = r->szakaszok; iter->kov != NULL; iter = iter->kov)
            ;
        iter->kov = uj;
    }

    /* minden ok */
    return 1;
}


/* Új rajzot kezd. Ennek egy inicializálatlan struktúrára mutató
 * pointert kell adni. Maga a struktúra már le kell legyen foglalva! */
void rajz_inicializal(Rajz *r, int kx, int ky, double ox, double oy, double nx, double ny) {
    /* Megjegyzi a nagyítást és az eltolást */
    r->kx = kx;
    r->ky = ky;
    r->ox = ox;
    r->oy = oy;
    r->nx = nx;
    r->ny = ny;
    /* Üres lista; NULL pointer, hogy ne az inicializálatlan struktúrára
     * hívjuk rá az üres koordinátarendszert rajzoló függvényt. */
    r->szakaszok = NULL;
    rajz_ures(r);
}


/* Felszabadítja a rajz által foglalt területet.
 * Maga a struktúra nem feltétlenül dinamikusan foglalt, ezért azt ez
 * a függvény nem szabadítja fel! */
void rajz_felszabadit(Rajz *r) {
    while (r->szakaszok != NULL) {
        Szakasz *kov = r->szakaszok->kov;
        free(r->szakaszok);
        r->szakaszok = kov;
    }
}

/* Már inicializált rajzot töröl. */
void rajz_ures(Rajz *r) {
    double ex, ey;

    /* Kezdetben nincs rajta vonal: a lista felszabadítása. */
    while (r->szakaszok != NULL) {
        Szakasz *kov = r->szakaszok->kov;
        free(r->szakaszok);
        r->szakaszok = kov;
    }
    /* Koordinátarendszer, x tengely */
    szakasz_rajzol(r, 0, r->oy, r->kx, r->oy, alapszin);
    szakasz_rajzol(r, r->kx, r->oy, r->kx-nyilmeret*2, r->oy-nyilmeret, alapszin);
    szakasz_rajzol(r, r->kx, r->oy, r->kx-nyilmeret*2, r->oy+nyilmeret, alapszin);
    /* Koordinátarendszer, y tengely */
    szakasz_rajzol(r, r->ox, 0, r->ox, r->ky, alapszin);
    szakasz_rajzol(r, r->ox, 0, r->ox-nyilmeret, nyilmeret*2, alapszin);
    szakasz_rajzol(r, r->ox, 0, r->ox+nyilmeret, nyilmeret*2, alapszin);
    /* egységek */
    mat2kep(r, 1, 1, &ex, &ey);
    szakasz_rajzol(r, ex, r->oy-nyilmeret, ex, r->oy+nyilmeret, alapszin);
    szakasz_rajzol(r, r->ox-nyilmeret, ey, r->ox+nyilmeret, ey, alapszin);
}


/* Kirajzol egy függvényt. */
int fuggveny_rajzol(Rajz *r, double (*fv)(double), char const *szin) {
    double const lepes = 1.0;
    double xk, yk, xelozo, yelozo;  /* kép koordináták */

    /* Haladjunk a kép koordinátái szerint, így pont olyan
     * részletességet kapunk, mint amekkora a kép. */
    for (xk=0; xk<=r->kx; xk+=lepes) {
        double xmat, ymat;

        /* Melyik matematikai x koordináta felel meg ennek? */
        kep2mat(r, xk, 0, &xmat, NULL);
        /* Azt kell a függvénybe behelyettesíteni */
        ymat=fv(xmat);
        /* Visszaszámolni képkoordinátákra megint */
        mat2kep(r, xmat, ymat, NULL, &yk);
        /* Utána rajz (kivétel a legelső helyen, mert azelőtt
         * még nincs előző pont). */
        if (xk!=0)
            if (!szakasz_rajzol(r, xk, yk, xelozo, yelozo, szin))
                /* ha baj van a rajzolással, megállunk */
                return 0;

        /* a következő iteráció számára */
        xelozo = xk;
        yelozo = yk;
    }

    /* sikerült teljesen kirajzolni, visszatérünk igaz értékkel */
    return 1;
}


/* Nyitott fájlba rakja az SVG elemeket. */
void rajz_kiir(Rajz const *r, FILE *fp) {
    Szakasz *iter;

    fprintf(fp, "<svg width=\"%d\" height=\"%d\" xmlns=\"http://www.w3.org/2000/svg\">\n",
        r->kx, r->ky);
    for (iter = r->szakaszok; iter != NULL; iter = iter->kov)
        fprintf(fp, "  <line x1=\"%g\" y1=\"%g\" x2=\"%g\" y2=\"%g\" stroke=\"%s\" />\n",
            iter->x1, iter->y1, iter->x2, iter->y2, iter->szin);
    fprintf(fp, "</svg>\n");
}


/* Adott nevű fájlba írja a rajzot. */
void rajz_fajlba(Rajz const *r, char const *nev) {
    FILE *fp;

    fp = fopen(nev, "wt");
    if (fp==NULL)   /* Nem sikerült megnyitni? */
        return;
    rajz_kiir(r, fp);
    fclose(fp);
}
