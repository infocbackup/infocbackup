#ifndef FUGGVENY_H
#define FUGGVENY_H

#include <stdio.h>

/** A Szakasz struktúra egy szakasz adatait tárolja egy rajzon. */
typedef struct Szakasz {
    /** Koordináták, már a kép koordinátarendszerében. */
    double x1, y1, x2, y2;
    /** A szakasz színe. */
    char szin[20+1];
    /** Pointer a láncolt listához. */
    struct Szakasz *kov;
} Szakasz;


/** A Rajz struktúra egy (vagy több) megrajzolt függvény
 * adatait tartalmazza, lényegében magát a képet. */
typedef struct Rajz {
    /** Kép mérete képpontokban */
    int kx, ky;
    /** Origó - mely képkoordinátákon van az origó */
    double ox, oy;
    /** Nagyítás - hány képpont jelenti az egységet */
    double nx, ny;
    /** A kép szakaszai: strázsa nélküli láncolt lista. */
    Szakasz *szakaszok;
} Rajz;


/** Új rajzot hoz létre.
 * Inicializálható vele memóriaszemetet tartalmazó rajz struktúra is,
 * de egy már használt rajz struktúra törlésére is használható.
 * @param r Pointer a rajz struktúrára, amit inicializálni kell.
 * @param kx A létrehozott kép szélessége, képpontokban.
 * @param ky A létrehozott kép magassága, képpontokban.
 * @param ox Az origó x koordinátája, kép koordinátarendszerben.
 * @param oy Az origó y koordinátája, kép koordinátarendszerben.
 * @param nx x irányú nagyítás: hány képernyőn látható képpont az egység vízszintesen.
 * @param ny y irányú nagyítás: hány képernyőn látható képpont az egység függőlegesen.
 */
void rajz_inicializal(Rajz *r, int kx, int ky, double ox, double oy, double nx, double ny);


/** Felszabadít egy rajzhoz tartozó minden memóriaterületet.
 * Akkor kell meghívni, ha az adott rajz struktúrára már többé nincs szükség.
 * @param r Pointer a rajz struktúrára, amire már a rajz_inicializal() meg lett hívva.
 */
void rajz_felszabadit(Rajz *r);

/**
 * Új rajzot kezd, egy üres koordinátarendszerrel.
 * A rajzon lévő eddigi összes függvény törlődik, és egy üres koordinátarendszert
 * rajzol bele a függvény.
 * @param r A törlendő rajz. Nem lehet memóriaszemét, már inicializálva kell legyen.
 */
void rajz_ures(Rajz *r);


/** Kiírja a paraméterként kapott fájlba egy rajz tartalmát SVG-ben.
 * @param r A rajz, amit meg kell jeleníteni.
 * @param fp Az írásra megnyitott szövegfájl, ahova írni kell a rajzot. */
void rajz_kiir(Rajz const *r, FILE *fp);


/** Kiírja egy SVG fájlba a rajz tartalmát.
 * @param r A rajz, amit meg kell jeleníteni.
 * @param nev A szövegfájl neve. */
void rajz_fajlba(Rajz const *r, char const *nev);


/**
 * Ábrázolja a paraméterként kapott függvényt.
 * @param r Rajz, amire a függvényt ábrázolni kell. Ebből veszi a nagyítás adatait is.
 * @param fv Pointer a függvényre, amit ábrázolni kell (double paraméterű, double visszatérési értékű).
 * @param szin A szín, amivel rajzolni kell (pl. "red").
 * @return HAMIS, ha rajzolás közben megtelt a rajz tárolója, IGAZ, ha minden rendben volt
 */
int fuggveny_rajzol(Rajz *r, double (*fv)(double), char const *szin);

#endif
