#include <stdio.h>
#include <math.h>
#include <string.h>
#include "fuggveny.h"

/**
 * @mainpage
 * Ez az előadáson bemutatott függvényrajzoló program
 * dokumentációja.
 */

/* Ez a struktúra egy parabola együtthatóit tárolja. */
typedef struct parabola_t {
    double a, /**< A másodfokú tag együtthatója. */
           b, /**< Az elsőfokú tag együtthatója. */
           c; /**< A nulladfokú (konstans) tag. */
} parabola_t;
/** Globális változó a parabola() függvény számára.
 * Ezekre azért van szükség, mert a parabola is egy y=f(x)
 * alakú függvény kell legyen, vagyis csak egy paramétere
 * lehet (az x). Az együtthatókat más módon kell megadni neki. */
static parabola_t parabola_adat;

/** Visszaadja x*x-x-1.5 értékét.
 * @param x A szám, amit a függvénybe be kell helyettesíteni.
 * @return A függvény értéke. */
static double parabola(double x) {
    return parabola_adat.a*x*x + parabola_adat.b*x + parabola_adat.c;
}


/** Kiírja a felhasználói menüt (főmenü), és megkérdezi a felhasználó választását.
 * @return A választott menü sorszáma, vagy 0 a kilépéshez (és hiba esetén). */
static int menu(void) {
    int valaszt, sik;

    printf("Menü (0: kilépés)\n");
    printf("  1. sin(x) rajzolása\n");
    printf("  2. axx+bx+c parabola rajzolása\n");
    printf("  3. Törlés\n");
    printf("  4. Fájlba mentés\n");
    printf("? ");
    /* A menü számának beolvasása. Az utána nyomott entert a getchar() lenyeli. */
    sik = scanf("%d", &valaszt)==1;
    getchar();
    /* Beolvasási hiba? 0-t adunk vissza (kilépésnek megfelelő) */
    if (!sik)
        return 0;
    /* Tartomány oké? Ha nem, 0-t ad vissza */
    if (valaszt>4 || valaszt<0)
        return 0;
    /* A választott menüpont */
    return valaszt;
}


/**
 * Főprogram. */
int main(int argc, char *argv[]) {
    enum { FAJLNEV_TOMB = 100 };
    char fajlnev[FAJLNEV_TOMB];
    Rajz r1;
    int v;

    rajz_inicializal(&r1, 320, 120, 160, 60, 25, 25);

    do {
        v = menu();
        switch (v) {
            case 1:
                fuggveny_rajzol(&r1, sin, "blue");
                break;
            case 2:
                printf("A parabola együtthatói:\n");
                scanf("%lf %lf %lf", &parabola_adat.a,
                    &parabola_adat.b, &parabola_adat.c);
                fuggveny_rajzol(&r1, parabola, "red");
                break;
            case 3:
                rajz_ures(&r1);
                break;
            case 4:
                printf("Mi legyen a fájl neve?\n");
                fgets(fajlnev, FAJLNEV_TOMB, stdin);
                /* fgets beleteszi az entert is, kitoroljuk */
                *strchr(fajlnev, '\n') = 0;
                rajz_fajlba(&r1, fajlnev);
                break;
        }
    } while (v != 0);

    rajz_felszabadit(&r1);

    return 0;
}

