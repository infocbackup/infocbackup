#include <stdio.h>
#include <ctype.h>
#include <string.h>

#include "elemzo.h"

/*
	A NYELVTAN:

	osszeg = szorzat {('+' | '-') szorzat}
	szorzat = tenyezo {('*' | '/') tenyezo}
	tenyezo = cellacim | szam | zarojeles
	zarojeles = '(' osszeg ')'
*/

/* Lexer függvények */
static int szokoz(char **szoveg);
static int karakter(char **szoveg, char const *ertekkeszlet, char *talalat);
static int szam(char **szoveg, double *ertek);
static int cellacim(char **szoveg, char *oszlop, int *sor);

/* Parser függvények */
static int osszeg(char **szoveg, double *ertek, tablazat *a_tablazat);
static int szorzat(char **szoveg, double *ertek, tablazat *a_tablazat);
static int tenyezo(char **szoveg, double *ertek, tablazat *a_tablazat);
static int zarojeles(char **szoveg, double *ertek, tablazat *a_tablazat);


/* Lexer függvények */
static int szokoz(char **szoveg) {
	while (isspace(**szoveg)) *szoveg += 1;
	return 1;
}


static int karakter(char **szoveg, char const *ertekkeszlet, char *talalat) {
	char *munka = *szoveg;

	szokoz(&munka);

	while (*ertekkeszlet && munka[0] != *ertekkeszlet) {
		++ertekkeszlet;
	}

	if (*ertekkeszlet == 0) {
		return 0;
	}
	else {
		*talalat = *ertekkeszlet;

		*szoveg = munka + 1;
		return 1;
	}
}


static int szam(char **szoveg, double *ertek) {
	char *munka = *szoveg;
    int bajtok;
    double szam;

	szokoz(&munka);
	if (sscanf(munka, "%lf%n", &szam, &bajtok) >= 1) {
        munka += bajtok;
        *ertek = szam;
        *szoveg = munka;
        return 1;
	}
	else {
		return 0;
	}
}


static int cellacim(char **szoveg, char *oszlop, int *sor) {
	char *munka = *szoveg;

	szokoz(&munka);
	if (isalpha(munka[0])) {
		int bajtok;

		*oszlop = toupper(munka[0]);

		munka += 1;
        if (sscanf(munka, "%d%n", sor, &bajtok)>=1) {
            munka += bajtok;
			*szoveg = munka;
			return 1;
		}
	}

	return 0;
}


/* Parser függvények */
static int osszeg(char **szoveg, double *ertek, tablazat *a_tablazat) {
	char *munka = *szoveg;
	char kar;
	double ertek_1, ertek_2;

	szokoz(&munka);
	if (szorzat(&munka, &ertek_1, a_tablazat)) {
		while (karakter(&munka, "+-", &kar)) {
			if (szorzat(&munka, &ertek_2, a_tablazat)) {
				ertek_1 = (kar == '+') ? ertek_1 + ertek_2 : ertek_1 - ertek_2;
			}
			else return 0;
		}
		*ertek = ertek_1;
        *szoveg = munka;
		return 1;
	}
	else {
		return 0;
	}
}


static int szorzat(char **szoveg, double *ertek, tablazat *a_tablazat) {
	char *munka = *szoveg;
	char kar;
	double ertek_1, ertek_2;

	szokoz(&munka);
	if (tenyezo(&munka, &ertek_1, a_tablazat)) {
		while (karakter(&munka, "*/", &kar)) {
			if (tenyezo(&munka, &ertek_2, a_tablazat)) {
				ertek_1 = (kar == '*') ? ertek_1 * ertek_2 : ertek_1 / ertek_2;
			}
			else return 0;
		}
		*ertek = ertek_1;
        *szoveg = munka;
		return 1;
	}
	else {
		return 0;
	}
}


static int tenyezo(char **szoveg, double *ertek, tablazat *a_tablazat) {
	char *munka = *szoveg;
	char oszlop;
	int sor;

	szokoz(&munka);
	if (zarojeles(&munka, ertek, a_tablazat)) {
        *szoveg = munka;
		return 1;
	}
	else if (szam(&munka, ertek)) {
        *szoveg = munka;
		return 1;
	}
	else if (cellacim(&munka, &oszlop, &sor)) {
		if (cella_kiszamol(a_tablazat, sor, oszlop - 'A')) {
			*ertek = a_tablazat->adat[sor][oszlop - 'A'].cachelt_ertek;
            *szoveg = munka;
			return 1;
		}
	}

	return 0;
}


static int zarojeles(char **szoveg, double *ertek, tablazat *a_tablazat) {
	char *munka = *szoveg;
	char kar;

	szokoz(&munka);
	if (karakter(&munka, "(", &kar) && osszeg(&munka, ertek, a_tablazat) && karakter(&munka, ")", &kar)) {
        *szoveg = munka;
		return 1;
	}
	else {
		return 0;
	}
}


int kiertekel(char *szoveg, double *ertek, tablazat *a_tablazat) {
    return osszeg(&szoveg, ertek, a_tablazat);
}
