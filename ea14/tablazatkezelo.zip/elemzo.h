#ifndef ELEMZO_H
#define ELEMZO_H

#include "tablazat.h"

int kiertekel(char *szoveg, double *ertek, tablazat *a_tablazat);

#endif /* ELEMZO_H */
