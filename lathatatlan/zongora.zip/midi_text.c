#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "midi_text.h"

static void esemeny_listaba_beszur_uj(Esemeny *lista, Esemeny ezt) {
    Esemeny *iter, *lemarado, *uj;
    
    uj = (Esemeny *) malloc(sizeof(Esemeny));
    *uj = ezt;
    for (lemarado = lista, iter = lemarado->kov;
         iter != NULL && uj->ido >= iter->ido;
         lemarado = iter, iter = iter->kov)
        ;   /* üres, csak keres */
    uj->kov = iter;
    lemarado->kov = uj;
}


void esemeny_lista_felszab(Esemeny *l) {
    l = l->kov; /* strazsa nem din */
    while (l != NULL) {
        Esemeny *temp = l->kov;
        free(l);
        l = temp;
    }
}


void fajl_beolvas(Esemeny *lista, char *fajlnev, int *clockperdiv) {
    char sor[100];
    FILE *fp;

    /* fajl megnyit */
    fp = fopen(fajlnev, "rt");
    if (!fp) {
        printf("Nem sikerult beolvasni!\n");
        return;
    }
    
    while (fgets(sor, sizeof(sor), fp)) {
        {
            //~ 0, 0, Header, format, nTracks, division
            int i;
            if (sscanf(sor, "%*d , %*d , Header , %*d , %*d , %d", &i)==1)
                *clockperdiv = i;
        }

        {
           //~ Track, Time, Tempo, Number
            int i;
            if (sscanf(sor, "%*d , %*d , Tempo , %d", &i)==1) {
                Esemeny et;
                et.tipus = tempobeallit;
                et.tempo = i;
                
                esemeny_listaba_beszur_uj(lista, et);
            }
        }

        {
            Esemeny e;
            char parancs[100];
            
            // 2, 6656, Note_on_c, 1, 67, 57
            if (sscanf(sor, "%*d , %d , %[^,] , %d , %d , %d",
                       &e.ido, parancs, &e.csatorna, &e.hangmagassag, &e.hangero) == 5) {
                if (e.csatorna != 9) {  /* dob kihagy */
                    if (strcmp(parancs, "Note_off_c")==0) {
                        e.tipus = hangki;
                        esemeny_listaba_beszur_uj(lista, e);
                    }
                    if (strcmp(parancs, "Note_on_c")==0) {
                        e.tipus = e.hangero == 0 ? hangki : hangbe;
                        esemeny_listaba_beszur_uj(lista, e);
                    }
                }
            }
        }
    }
}


