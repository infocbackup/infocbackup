typedef enum EsemenyTipus {
    hangbe, hangki, tempobeallit,
} EsemenyTipus;


typedef struct Esemeny {
    EsemenyTipus tipus;
    /* tempohoz */
    int tempo;
    /* hanghoz */
    int ido;
    int csatorna;
    int hangmagassag;
    int hangero;
    
    struct Esemeny *kov;
} Esemeny;


void esemeny_lista_felszab(Esemeny *l);
void fajl_beolvas(Esemeny *lista, char *fajlnev, int *clockperdiv);
