typedef struct HangSzin {
    double felfutas_ido;        /* masodperc */
    double lecsenges_ido;       /* masodperc */
    double tartas_hangero;      /* arany 1-hez kepest */
    double tartas_halkulas_ido; /* masodperc */
    double elengedes_ido;       /* masodperc */
} HangSzin;


typedef enum HangAllapot {
    csend, felfutas, lecsenges, tartas, elengedes
} HangAllapot;


typedef struct Hang {
    int csatorna;
    int hangmagassag;           /* a frekvenciaja */
    double hangero;             /* midi hangero */
    
    HangAllapot all;            /* aktualis allapot a burkologorbehez */
    double adsrhangero;         /* a hangero, 0->1 és 1->0 valtoztatva, hogy ne pattogjon */
    
    struct Hang *kov;
} Hang;


typedef struct Szinti {
    double hangero;
    HangSzin *hangszin;
    Hang *hangok;
} Szinti;


void hang_init(Szinti *szinti);
void hang_start(void);
void hang_stop(void);
void hang_mar_nem_kell_torol(Hang *h);
Hang *hang_keres(Hang *hangok, int csatorna, int hangmagassag);
void hang_lista_felszab(Hang *h);
