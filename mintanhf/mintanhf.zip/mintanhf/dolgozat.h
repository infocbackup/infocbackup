#ifndef DOLGOZAT_H
#define DOLGOZAT_H

#include "szohalmaz.h"

/* Egy dolgozat adatait tároló adatszerkezet.
 * Benne a fájl neve, a szerző azonosítói,
 * és a kifejezések - halmazok tömbjeként.
 * Láncolt listába fűzhető. */
typedef struct Dolgozat {
    char fajlnev[33];
    char nev[45];
    Halmaz *kifejezesek;
    
    struct Dolgozat *kov;
} Dolgozat;


Dolgozat *uj_dolgozat(char *fajlnev, char *nev);
void dolgozatok_felszabadit(Dolgozat *dolgozatok);
int dolgozatok_meret(Dolgozat* dolgozatok);

#endif
