#ifndef INTHALMAZ_H
#define INTHALMAZ_H


typedef struct Halmaz Halmaz;

enum { SZOHOSSZ=50 };

void halmaz_betesz(Halmaz **phalmaz, char *szo);
int halmaz_metszet_meret(Halmaz *h1, Halmaz *h2);
int halmaz_meret(Halmaz *h);
void halmaz_felszabadit(Halmaz *h);

#endif
