angol.txt: Angol szavak

magyar_latin2.txt: Magyar szavak, latin2 kodolassal.
                   Linuxon utf8 keszitheto belole: iconv --from latin2 --to utf8

magyar_ascii.txt: Magyar szavak, ascii kodolassal. Ekezetek nelkul.

szotar.txt: Angol:magyar formatumban szotar.
            Ez is latin2, iconvval gyarthato belole utf8.
